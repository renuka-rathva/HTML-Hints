import React, { useState,useEffect } from 'react'
import './CSS/tempStyle.css'
import pic from './Image/logo.png';



const TempApp = () => {

    const  [data, setData] = useState(null);
    const [search, setSearch] = useState();

    useEffect(() => {
        const getApiData = async()=>{
            const url = `http://api.openweathermap.org/data/2.5/weather?q=${search}&units=metric&appid=8e1a3abf6d75170d8b242fbf9a23da7d`;

            const res = await fetch(url);
            const resData = await res.json();
            // console.log(resData);
            setData(resData.main);
        }
        getApiData();
    },[search])

    return (
        <>
            <div className="box">  
                <div className="blur">
                    <div className="title-head">
                    <img className="banner" src= {pic} alt="" />
                    <h1>Weather App</h1>
                    </div>
                    <input type="search" name="" id="" onChange={(event)=>{setSearch(event.target.value)}} />
                    {!data?(<p>Data not found</p>):(<>
                    <h2>{search}</h2>
                    <h2>{data.temp} &deg;C</h2>
                    </>)}
                </div>
            </div>
       
            
        </>
    ) 
}

export default TempApp
