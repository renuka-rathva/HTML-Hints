import TempApp from '../src/components/TempApp';
import './App.css';

function App() {
  return (
    <div className="App">
      <TempApp/>    

    </div>
  );
}

export default App;
